package com.primeiroprojeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroProjetoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
