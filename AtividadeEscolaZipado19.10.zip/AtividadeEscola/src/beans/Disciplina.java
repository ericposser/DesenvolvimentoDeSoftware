/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author eric_
 */
public class Disciplina {
    private int id, carga;
    private String nome;
    private Professor professorid;

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    

    public Professor getProfessorid() {
        return professorid;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

   

    public void setProfessorid(Professor professorid) {
        this.professorid = professorid;
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        this.carga = carga;
    }
    
    
    
}
