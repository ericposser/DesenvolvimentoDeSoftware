/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

/**
 *
 * @author laboratorio
 */
public class Conexao {
     public Connection getConexao(String escola){
        try{
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/escola?useTimezone=true&serverTimezone=UTC", "root", "99278605eeE");
            return con;
        }
        catch(Exception e){
            System.out.println("erro ao conectar" + e.getMessage());
            return null;
        }
       
    }
}
