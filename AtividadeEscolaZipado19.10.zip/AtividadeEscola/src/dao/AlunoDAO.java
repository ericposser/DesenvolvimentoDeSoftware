/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Aluno;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class AlunoDAO {
    private Conexao conexao;
    private Connection con;
    
    public AlunoDAO(){
        this.conexao = new Conexao();
        this.con = this.conexao.getConexao("escola");
    }
    
    public void inserir (Aluno aluno){
        String sql = "INSERT INTO aluno (nome, idade, curso) VALUES (?,?,?)";
        
        try{
            PreparedStatement stmt = this.con.prepareStatement(sql);
            
            stmt.setString(1, aluno.getNome());
            stmt.setInt(2, aluno.getIdade());
            stmt.setString(3, aluno.getCurso());
            
            stmt.execute();
        } catch(SQLException ex){
            System.out.println("erro ao inserir Aluno:" + ex.getMessage());
        }
    }
    
    public Aluno getAluno(int id) {
        String sql = "SELECT * FROM aluno Where id = ?";
        try {
            PreparedStatement smt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            smt.setInt(1, id);
            ResultSet rs = smt.executeQuery();

            Aluno a = new Aluno();

            rs.first();

            a.setId(id);
            a.setNome(rs.getString("nome"));
            a.setIdade(rs.getInt("idade"));
            a.setCurso(rs.getString("curso"));

            return a;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar aluno: " + ex.getMessage());
            return null;
        }
    }
    
    public List<Aluno> getAlunosNome(String nome){
        String sql = "SELECT * FROM aluno WHERE nome LIKE ?";
        
        try{
             PreparedStatement stmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
             stmt.setString(1, "%" + nome + "%");
             ResultSet rs = stmt.executeQuery();
             List<Aluno> listaAlunos = new ArrayList();
             
             while(rs.next()){
                 Aluno a = new Aluno();
                 
                 a.setId(rs.getInt("id"));
                 a.setNome(rs.getString("nome"));
                 a.setIdade(rs.getInt("idade"));
                 a.setCurso(rs.getString("curso"));
                 
                 listaAlunos.add(a);
             }
             return listaAlunos;
        }catch(SQLException ex){
            return null;
        }
    }
    
     public void editar(Aluno a) {
        try {
            String sql = "UPDATE aluno set nome=?, idade=?, curso=? where id=?";
            PreparedStatement smt = con.prepareStatement(sql);
            smt.setString(1, a.getNome());
            smt.setInt(2, a.getIdade());
            smt.setString(3, a.getCurso());
            smt.setInt(4, a.getId());
            smt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar aluno: " + ex.getMessage());
        }
    }
     
      public void Excluir(int id) {
        try {
            String sql = "delete from aluno where id=?";

            PreparedStatement smt = con.prepareStatement(sql);
            smt.setInt(1, id);
            smt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir aluno: "+ex.getMessage());
        }
    }
    
}
