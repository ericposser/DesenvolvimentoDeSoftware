/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Disciplina;
import conexao.Conexao;
import java.sql.*;
import java.util.*;

/**
 *
 * @author eric_
 */
public class DisciplinaDAO {
    private Conexao conexao;
    private Connection conn;
    
     public DisciplinaDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao("escola");
    }
     
      public void inserir(Disciplina disciplina) {
        String sql = "INSERT INTO disciplina (nome, carga, id_professor) VALUES (?,?,?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, disciplina.getNome());
            stmt.setInt(2, disciplina.getCarga());
            stmt.setInt(3, disciplina.getProfessorid().getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir disciplina: " + ex.getMessage());
        }

    }
      
      public void editar(Disciplina disciplina) {
        String sql = "UPDATE INTO disciplina set nome=?, carga=?, id_professor=?, WHERE id=?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, disciplina.getNome());
            stmt.setInt(2, disciplina.getCarga());
            stmt.setInt(3, disciplina.getProfessorid().getId());
            stmt.setInt(4, disciplina.getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar disciplina: " + ex.getMessage());
        }

    }
      
      public void excluir(int id) {
        try {
            String sql = "delete from disciplina where id=?";

            PreparedStatement stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("erro ao excluir" + ex.getMessage());
        }
    }
      
      public List<Disciplina> getDisciplinas(){
        String sql = "SELECT * FROM disciplina";
        
        try{
             PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
             
             ResultSet rs = stmt.executeQuery();
             List<Disciplina> listaDisciplinas = new ArrayList();
             
             while(rs.next()){
                 Disciplina d = new Disciplina();
                 
                 d.setId(rs.getInt("id"));
                 d.setNome(rs.getString("nome"));
                 d.setCarga(rs.getInt("carga"));
                 
                 ProfessorDAO pDAO = new ProfessorDAO();
                 d.setProfessorid(pDAO.getProfessor(rs.getInt("id_professor")));
                 
                 listaDisciplinas.add(d);
             }
             return listaDisciplinas;
        }catch(SQLException ex){
            return null;
        }
    }
}
