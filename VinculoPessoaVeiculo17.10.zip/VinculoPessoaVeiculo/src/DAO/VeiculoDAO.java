/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Beans.Pessoa;
import Beans.Veiculo;
import conexaobancodedados.Conexao;
import java.sql.*;
import java.util.*;

/**
 *
 * @author laboratorio
 */
public class VeiculoDAO {

    private Conexao conexao;
    private Connection conn;

    public VeiculoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao("aula");
    }

    public void inserir(Veiculo veiculo) {
        String sql = "INSERT INTO veiculo (modelo, placa, id_pessoa) VALUES (?,?,?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, veiculo.getModelo());
            stmt.setString(2, veiculo.getPlaca());
            stmt.setInt(3, veiculo.getPessoaid().getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir veiculo: " + ex.getMessage());
        }

    }

    public void editar(Veiculo veiculo) {
        String sql = "UPDATE INTO veiculo set modelo=?, placa=?, id_pessoa=?, WHERE id=?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, veiculo.getModelo());
            stmt.setString(2, veiculo.getPlaca());
            stmt.setInt(3, veiculo.getPessoaid().getId());
            stmt.setInt(4, veiculo.getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar veiculo: " + ex.getMessage());
        }

    }

    public void excluir(int id) {
        try {
            String sql = "delete from veiculo where id=?";

            PreparedStatement stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("erro ao excluir" + ex.getMessage());
        }
    }
    
     public List<Veiculo> getVeiculos(){
        String sql = "SELECT * FROM veiculo";
        
        try{
             PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
             
             ResultSet rs = stmt.executeQuery();
             List<Veiculo> listaVeiculos = new ArrayList();
             
             while(rs.next()){
                 Veiculo v = new Veiculo();
                 
                 v.setId(rs.getInt("id"));
                 v.setModelo(rs.getString("modelo"));
                 v.setPlaca(rs.getString("placa"));
                 
                 PessoaDao pDAO = new PessoaDao();
                 v.setPessoaid(pDAO.getPessoa(rs.getInt("id_pessoa")));
                 
                 listaVeiculos.add(v);
             }
             return listaVeiculos;
        }catch(SQLException ex){
            return null;
        }
    }
    
}
