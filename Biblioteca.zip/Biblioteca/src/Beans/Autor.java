/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Beans;

import Conexao.InputNum;
import java.util.Calendar;

/**
 *
 * @author eric_
 */
public class Autor {
    private int id;
    private String nome, nacionalidade, dataNasci;
    private Livro livroid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    
    public String getNome() {
        return nome;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public String getDataNasci() {
        return dataNasci;
    }

    public Livro getLivroid() {
        return livroid;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public void setDataNasci(String dataNasci) {
        this.dataNasci = dataNasci;
    }

    public void setLivroid(Livro livroid) {
        this.livroid = livroid;
    }
    
    
}
