/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author eric_
 */
public class Conexao {
    public Connection getConexao(String BD){
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/biblioteca?useTimezone=true&serverTimezone=UTC", "root", "laboratorio");
            System.out.println("Conexao bem sucedida!");
            return conn;
        } catch (Exception e) {
            System.out.println("Erro ao conectar no BD "+e.getMessage());
            return null;
        }
    }
}
