/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Beans.Livro;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author eric_
 */
public class LivroDAO {

    private Conexao conexao;
    private Connection conn;

    public LivroDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao("biblioteca");

    }

    public void inserir(Livro livro) {
        String sql = "INSERT INTO livro (titulo,autor,genero,ano,numCopia) VALUES (?,?,?,?,?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, livro.getTitulo());
            stmt.setString(2, livro.getAutor());
            stmt.setString(3, livro.getGenero());
            stmt.setInt(4, livro.getAno());
            stmt.setInt(5, livro.getNumCopia());

            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir livro: " + ex.getMessage());
        }

    }

    public Livro getLivro(int id) {
        String sql = "SELECT * FROM livro WHERE id = ?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Livro l = new Livro();

            rs.first();
            l.setId(id);
            l.setTitulo(rs.getString("titulo"));
            l.setAutor(rs.getString("autor"));
            l.setGenero(rs.getString("genero"));
            l.setAno(rs.getInt("ano"));
            l.setNumCopia(rs.getInt("numCopia"));
            return l;

        } catch (SQLException ex) {
            System.out.println("erro" + ex.getMessage());
            return null;
        }
    }

    public List<Livro> getLivros() {
        String sql = "SELECT * FROM livro";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            ResultSet rs = stmt.executeQuery();
            List<Livro> listaLivros = new ArrayList();

            while (rs.next()) {
                Livro l = new Livro();

                l.setId(rs.getInt("id"));
                l.setTitulo(rs.getString("titulo"));
                l.setAutor(rs.getString("autor"));
                l.setGenero(rs.getString("genero"));
                l.setAno(rs.getInt("ano"));
                l.setNumCopia(rs.getInt("numCopia"));

                listaLivros.add(l);
            }
            return listaLivros;
        } catch (SQLException ex) {
            return null;
        }
    }

    public List<Livro> getLivrosAuto(String autor) {
        String sql = "SELECT * FROM livro WHERE autor LIKE ?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%" + autor + "%");
            ResultSet rs = stmt.executeQuery();
            List<Livro> listaLivros = new ArrayList();

            while (rs.next()) {
                Livro l = new Livro();

                l.setId(rs.getInt("id"));
                l.setTitulo(rs.getString("titulo"));
                l.setAutor(rs.getString("autor"));
                l.setGenero(rs.getString("genero"));
                l.setAno(rs.getInt("ano"));
                l.setNumCopia(rs.getInt("numCopia"));

                listaLivros.add(l);
            }
            return listaLivros;
        } catch (SQLException ex) {
            return null;
        }
    }

    public void editar(Livro l) {
        try {
            String sql = "UPDATE livro set titulo=?, autor=?, genero=?, ano=?, numCopia=? where id=?";
            PreparedStatement smt = conn.prepareStatement(sql);
            smt.setString(1, l.getTitulo());
            smt.setString(2, l.getAutor());
            smt.setString(3, l.getGenero());
            smt.setInt(4, l.getAno());
            smt.setInt(5, l.getNumCopia());
            smt.setInt(6, l.getId());
            smt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar: " + ex.getMessage());
        }
    }
    
     public void excluir(int id){
        try{
            String sql = "delete from livro where id=?";
            
             PreparedStatement stmt = this.conn.prepareStatement(sql);
             
             stmt.setInt(1,id);
             stmt.execute();
            
        } catch(SQLException ex){
            System.out.println("erro ao excluir" + ex.getMessage());
        }
    }
}
