/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Beans.Autor;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author eric_
 */
public class AutorDAO {

    private Conexao conexao;
    private Connection conn;

    public AutorDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao("biblioteca");
    }

    public void inserir(Autor autor) {
        String sql = "INSERT INTO autor (nome, nacionalidade, dataNasci, livro_id) VALUES (?,?,?,?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, autor.getNome());
            stmt.setString(2, autor.getNacionalidade());
            stmt.setString(3, autor.getDataNasci());
            stmt.setInt(4, autor.getLivroid().getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir autor: " + ex.getMessage());
        }

    }

    public void editar(Autor autor) {
        String sql = "UPDATE autor SET nome=?, nacionalidade=?, dataNasci=?, livro_id=? WHERE id=?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, autor.getNome());
            stmt.setString(2, autor.getNacionalidade());
            stmt.setString(3, autor.getDataNasci());
            stmt.setInt(4, autor.getLivroid().getId());
            stmt.setInt(5, autor.getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar: " + ex.getMessage());
        }

    }

    public void excluir(int id) {
        try {
            String sql = "delete from autor where id=?";

            PreparedStatement stmt = this.conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("erro ao excluir" + ex.getMessage());
        }
    }

    public List<Autor> getAutores(String nome) {
        String sql = "SELECT * FROM autor WHERE nome LIKE ?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            List<Autor> listaAutores = new ArrayList();

            while (rs.next()) {
                Autor a = new Autor();

                a.setId(rs.getInt("id"));
                a.setNome(rs.getString("nome"));
                a.setNacionalidade(rs.getString("nacionalidade"));
                a.setDataNasci(rs.getString("dataNasci"));

                LivroDAO lDAO = new LivroDAO();
                a.setLivroid(lDAO.getLivro(rs.getInt("livro_id")));

                listaAutores.add(a);
            }
            return listaAutores;
        } catch (SQLException ex) {
            return null;
        }
    }

    public Autor getAutor(int id) {
        String sql = "SELECT * FROM autor Where id = ?";
        try {
            PreparedStatement smt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            smt.setInt(1, id);
            ResultSet rs = smt.executeQuery();

            Autor a = new Autor();

            rs.first();

            a.setId(id);
            a.setNome(rs.getString("nome"));
            a.setNacionalidade(rs.getString("nacionalidade"));
            a.setDataNasci(rs.getString("dataNasci"));

            LivroDAO lDAO = new LivroDAO();
            a.setLivroid(lDAO.getLivro(rs.getInt("livro_id")));

            return a;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar: " + ex.getMessage());
            return null;
        }
    }

}
